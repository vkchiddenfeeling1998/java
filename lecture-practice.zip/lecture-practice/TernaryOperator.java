import java.util.Scanner;
class TernaryOperator{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter any num");
	int i=sc.nextInt();
	String s = ( i%2==0)? i+" is even":i+" is odd";
	System.out.println(s);
	boolean b =(i%2==0)?true:false;
	System.out.println(b);
}
}