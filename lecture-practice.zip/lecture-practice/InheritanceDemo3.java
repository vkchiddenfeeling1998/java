class person{
	private String pName;
	void set(String pName){
		this.pName=pName;
	}
	void show(){
		System.out.println(pName);
	}
}
class Employee extends person{
	private float salary;
	void set(String pName,float salary){
		 set(pName);
		this.salary=salary;
	}
	void show(){
		super.show();
		System.out.println(salary);
	}
}
class Manager extends Employee{
	private String dept;
	void set(String pName,float salary,String dept){
		 set(pName,salary);
		this.dept=dept;
	}
	void show(){
		super.show();
		System.out.println(dept);
	}
}
class InheritanceDemo3{
	public static void main(String args[]){
		Manager m1=new Manager();
		m1.set("vaish",9000f,"computer");
		m1.show();
	}
}
