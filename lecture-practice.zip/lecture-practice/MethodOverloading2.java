class MathOpe{
	static void sum(float i,int j){
	float k =i+j;
	System.out.println(k);
	}
	static void sum(int i,float j){
	float k =i+j;
	System.out.println(k);
	}
}
class MethodOverloading2{
	public static void main(String args[]){
		MathOpe.sum(12.5f,13);
		MathOpe.sum(12,13.5f);

	}
}
