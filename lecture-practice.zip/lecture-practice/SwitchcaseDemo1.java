import java.util.Scanner;
class SwitchcaseDemo1{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter any character");
	char i=sc.next().charAt(0);
	switch(i){
		case 'a' :	
		case 'e' :
		case 'i' :	
		case 'o' :
		case 'u' :
		System.out.println(i + " is vowels is in lower");
		break;	
		case 'A' :
		case 'E' :
		case 'I' :	
		case 'O' :
		case 'U' :
		System.out.println(i + " is vowels is in upper");
		break;
		default :
		System.out.println(i + " is not vowels");

	}
}
}