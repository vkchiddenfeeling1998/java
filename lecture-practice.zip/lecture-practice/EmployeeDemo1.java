class Employee{
	int empId;
	String empName;
	void set(int empId,String empName){
		empId=empId;
		empName=empName;
	}
	void show(){
		System.out.println(empId+" "+empName);
	}
}
class EmployeeDemo1{
	public static void main(String args[]){
	Employee e= new Employee();
	e.set(101,"ram");
	e.show();
	}
}