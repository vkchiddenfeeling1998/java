class Employee{
	private int empId;
	private String empName;
	Employee(){
	empId=200;
	empName="vaishnavi";
	}
	Employee(int empId,String empName){
		this.empId=empId;
		this.empName=empName;
	}
	void show(){
		System.out.println(empId+" "+empName);
	}
}
class ConstructorDemo{
	public static void main(String args[]){
		Employee e= new Employee();
		e.show();
		Employee e1= new Employee(100,"darshu");
		e1.show();
	}
}