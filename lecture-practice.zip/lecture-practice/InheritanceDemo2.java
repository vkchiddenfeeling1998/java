class Employee{
	private int empId;
	private String empName;
	void set(int empId,String empName){
		this.empId=empId;
		this.empName=empName;
	}
	void show(){
		System.out.println(empId+" "+empName);
	}
}
class Manger extends Employee{
	private int ta;
	private int da;
	void set(int empId,String empName,int ta,int da){
		 set(empId,empName);
		this.ta=ta;
		this.da=da;
	}
	void show(){
		super.show();
		System.out.println(ta+" "+da);
	}
}
class Clerk extends Employee{
	private int hra;
	void set(int empId,String empName,int hra){
		 set(empId,empName);
		this.hra=hra;
	}
	void show(){
		super.show();
		System.out.println(hra);
	}
}
class InheritanceDemo2{
	public static void main(String args[]){
		Manger m1=new Manger();
		m1.set(102,"vaish",1000,2800);
		m1.show();
		Clerk c = new Clerk();
		c.set(202,"shiv",5000);
		c.show();


	}

}