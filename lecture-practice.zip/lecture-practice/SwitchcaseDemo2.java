import java.util.Scanner;
class SwitchcaseDemo2{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter any day no of week");
	byte dayNo = sc.nextByte();
	switch(dayNo){
		case 1:
			System.out.println("monday");
			break;	
		case 2:
			System.out.println("tuesday");
			break;	
		case 3:
			System.out.println("wednesday");
			break;	
		case 4:
			System.out.println("thursday");
			break;
		case 5:
			System.out.println("friday");
			break;
		case 6:
			System.out.println("saturaday");
			break;	
		case 7:
			System.out.println("sunday");
			break;			
		default :
			System.out.println(dayNo + " is not valid");

	}
}
}