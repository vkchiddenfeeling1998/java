class Employee{
	int empId;
	String empName;
	void set(int empId,String empName){
		this.empId=empId;
		this.empName=empName;
	}
	void show(){
		System.out.println(empId+" "+empName);
	}
}
class EmployeeDemo2{
	public static void main(String args[]){
	Employee e= new Employee();
	e.set(101,"ram");
	e.show();
	}
}