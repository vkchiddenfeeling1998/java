class Primitive{
	public static void main(String args[]){
		boolean b = false;
		char ch = 'A';
		byte by = 127;
		short sh = 345;
		int i = 6666;
		long l = 9_999_999_999L;
		float f = 45.50F;
		double d = 56.55D;
		System.out.println(b);
		System.out.println(ch);
		System.out.println(by);
		System.out.println(sh);
		System.out.println(i);
		System.out.println(l);
		System.out.println(f);
		System.out.println(d);
	}	
}

