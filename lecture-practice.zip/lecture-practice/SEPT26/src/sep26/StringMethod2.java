package sep26;

public class StringMethod2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "abc";
		System.out.println(s);
		String s1 = new String ("vaishu");
		System.out.println(s1);
		byte ar[] = {70,71,72,73,74};
		String s2 = new String(ar);
		System.out.println(s2);
		char arr1[] = {'a','b','c','d'};
		String s3 = new String(arr1);
		System.out.println(s3);
	}

}
