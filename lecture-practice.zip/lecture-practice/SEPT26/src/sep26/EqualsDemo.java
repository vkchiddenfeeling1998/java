package sep26;
class Employee{
	private int empId;
	private String empName;
	
	public Employee(int empId,String empName){
		this.empId= empId;
		this.empName=empName;
	}
	 @Override 
	 public String toString() {
		 return  empId +""+empName;
	 }
	 @Override 
	 public boolean equals(Object obj) {
		 if(obj== null)
			 return false;
		 if(obj instanceof Employee) {
			 Employee e=(Employee)obj;
			 return empId== e.empId;
		 }
		 return false;
	 }
	 
}
public class EqualsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1=new Employee(102,"vaish");
		Employee e2=e1;
		Employee e3= new Employee(103,"yash");
		Employee e4= new Employee(106,"patu");
		System.out.println("e1.equals(e2) "+e1.equals(e2));
		System.out.println("e1.equals(e3) "+e1.equals(e3));
		System.out.println("e1.equals(e4) "+e1.equals("abc"));
	}

}
