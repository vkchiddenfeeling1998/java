package sep26;

public class StringConcat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "vaishnavi";
		String s1 = "chouhan";
		String s2 = s.concat(s1);
		System.out.println(s);
		System.out.println(s1);
		System.out.println(s2);
		System.out.println("=======================");
		String s3 = "mango";
		s3 = s3.concat("is fruit");
		System.out.println(s3);
	}

}
