package sep26;
import java.util.*;
public class StringPassword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =  new Scanner(System.in);
		System.out.println("enter username");
		String s = sc.next();
		System.out.println("enter the password");
		String p = sc.next();
		if(s.equalsIgnoreCase("ram") && p.equals("abc") )
		{
			System.out.println("welcome");
		}else {
			System.out.println("try again");
		}
		
	}

}
