package sep26;

public class Exception5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("started");
		String ar[]= {"12","3","g"};
		try {
			String s1=ar[0];
			String s2=ar[2];
			int i= Integer.parseInt(s1);
			int j= Integer.parseInt(s2);
			int k=i/j;
			System.out.println(k);
		}catch(ArithmeticException | NumberFormatException | ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}
		System.out.println("finished");
	}

}
