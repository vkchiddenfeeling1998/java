package sep26;

public class StringMethod3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s ="immutable sequence of character";
		System.out.println(s);
		String s1= s.toUpperCase();
		System.out.println(s1);
		String s2 = s.toLowerCase();
		System.out.println(s2);
		int i= s.length();
		System.out.println(i);
		char ch =s.charAt(0);
		System.out.println(ch);
		int j = s.indexOf('r');
		System.out.println(j);
		int k = s.lastIndexOf('t');
		System.out.println(k);
		String s3 = s.substring(10);
		System.out.println(s3);
		String s4 = s.substring(10,18);
		System.out.println(s4);		
		}

}
