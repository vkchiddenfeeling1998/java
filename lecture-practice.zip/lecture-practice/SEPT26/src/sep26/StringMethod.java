package sep26;

public class StringMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder s = new StringBuilder("abc");
		System.out.println(s);
		s.append("def");
		System.out.println(s);
		s.insert(3,"Abc");
		System.out.println(s);
		s.replace(2, 5, "vaishu");
		System.out.println(s);
		s.delete(3,7);
		System.out.println(s);
	}

}
