package sep26;

public class StringSplit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "This is not done ";
		String ar[] = s.split(" ");
		for(String a : ar) {
			System.out.println(a);
		}
		System.out.println("==========================");
		String s1 = String.join(":", ar);
		System.out.println(s1);

	}

}
